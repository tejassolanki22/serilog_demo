using System;
using Microsoft.Extensions.Logging;
 class MyClass {

        private readonly ILogger _logger;

public MyClass (ILogger<MyClass> logger) {
            _logger = logger;
        }

        public void SomeMethod () {
            _logger.LogInformation("Hello");
        }

    }