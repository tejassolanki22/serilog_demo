﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Console;
using Serilog;

namespace Logger {
    

    class Program {

        static void Main (string[] args) {

            IConfiguration configuration = new ConfigurationBuilder ()
                .AddEnvironmentVariables ()
                .Build ();
            Log.Logger = new LoggerConfiguration ()
                .WriteTo.File ("consoleapp.log")
                .CreateLogger ();

            var serviceCollection = new ServiceCollection ();
            ConfigureServices (serviceCollection, configuration);

            var serviceProvider = serviceCollection.BuildServiceProvider ();

            serviceProvider.GetService<MyClass>().SomeMethod();

            var logger = serviceProvider.GetService<ILogger<Program>> ();

            logger.LogInformation ("Log in program.cs");

        }
        private static void ConfigureServices (IServiceCollection services, IConfiguration configuration) {
            services.AddLogging (configure => configure.AddSerilog ())
                .AddTransient<MyClass> ();
            if (configuration["Log_Level"] == "true") {
                services.Configure<LoggerFilterOptions> (options => options.MinLevel = LogLevel.Trace);

            } else {
                services.Configure<LoggerFilterOptions> (options => options.MinLevel = LogLevel.Error);
            }
        }
    }

}